import * as Node from "./Nodes";

export const nodeTypes = {
  send_email: Node.Source,
  send_sms: Node.Action,
  show_in_app: Node.Action,
  show_in_web: Node.Condition,
  end: Node.End,
  empty: Node.Empty,
  // drop: Node.dropZone
};
